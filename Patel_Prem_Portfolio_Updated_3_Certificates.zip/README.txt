# Patel Prem S. Portfolio

Open `index.html` in a browser to view the portfolio.

Instagram:
https://instagram.com/premm.093

Email:
patelprem8013@gmail.com

WhatsApp:
+91 93275 27129
